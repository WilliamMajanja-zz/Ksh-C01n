class Money
  VERSION = '6.10.1'
end
